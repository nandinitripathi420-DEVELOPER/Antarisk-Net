import SectionTitle from '../ui/SectionTitle.jsx'
import GlassPanel from '../ui/GlassPanel.jsx'
import UploadCard from './UploadCard.jsx'
import AIProcessing from './AIProcessing.jsx'
import OutputCard from './OutputCard.jsx'
import Metrics from './Metrics.jsx'

export default function Workspace() {
  return (
    <section id="workspace" className="relative px-6 py-28 md:px-10">
      <div className="mx-auto flex max-w-6xl flex-col gap-14">
        <SectionTitle
          eyebrow="Live Workspace"
          title="From cloud cover to clarity, in one pass"
          description="Drop in a cloud-obscured tile and watch the reconstruction pipeline rebuild the surface underneath — no manual masking required."
        />

        <div className="grid grid-cols-1 items-center gap-6 lg:grid-cols-[1fr_0.8fr_1fr]">
          <UploadCard />
          <GlassPanel className="p-6 md:p-8">
            <AIProcessing />
          </GlassPanel>
          <OutputCard />
        </div>

        <GlassPanel className="p-6 md:p-8">
          <h3 className="mb-6 font-display text-sm font-semibold text-mist-100">
            Reconstruction Quality
          </h3>
          <Metrics />
        </GlassPanel>
      </div>
    </section>
  )
}
