import { motion } from 'framer-motion'
import { BrainCircuit, Check } from 'lucide-react'

const STEPS = [
  'Detecting cloud masks',
  'Encoding spectral features',
  'Generative infill pass',
  'Refining surface detail',
]

export default function AIProcessing() {
  return (
    <div className="flex flex-col items-center gap-6 px-2">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
        className="relative flex h-20 w-20 items-center justify-center rounded-full"
        style={{
          background:
            'conic-gradient(from 0deg, var(--color-cyan-glow), var(--color-violet-glow), var(--color-cyan-glow))',
        }}
      >
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-space-900">
          <BrainCircuit className="h-7 w-7 text-cyan-glow" strokeWidth={1.75} />
        </div>
      </motion.div>

      <div className="flex w-full flex-col gap-3">
        {STEPS.map((step, i) => (
          <motion.div
            key={step}
            initial={{ opacity: 0, x: -12 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.15 }}
            className="flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.03] px-4 py-2.5"
          >
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-cyan-glow to-violet-glow">
              <Check className="h-3 w-3 text-space-950" strokeWidth={3} />
            </span>
            <span className="text-xs text-mist-300">{step}</span>
          </motion.div>
        ))}
      </div>

      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/8">
        <motion.div
          initial={{ width: '0%' }}
          whileInView={{ width: '100%' }}
          viewport={{ once: true }}
          transition={{ duration: 1.8, ease: [0.16, 1, 0.3, 1] }}
          className="h-full rounded-full bg-gradient-to-r from-cyan-glow to-violet-glow"
        />
      </div>
    </div>
  )
}
