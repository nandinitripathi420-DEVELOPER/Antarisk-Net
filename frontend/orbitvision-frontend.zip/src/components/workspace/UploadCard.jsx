import { motion } from 'framer-motion'
import { CloudUpload, ImageIcon } from 'lucide-react'
import Card from '../ui/Card.jsx'

export default function UploadCard() {
  return (
    <Card className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-sm font-semibold text-mist-100">Input Frame</h3>
        <span className="rounded-full bg-white/5 px-2.5 py-1 text-[10px] font-medium uppercase tracking-wider text-mist-500">
          Cloud-covered
        </span>
      </div>

      <div className="relative flex aspect-square items-center justify-center overflow-hidden rounded-2xl border border-dashed border-white/12 bg-space-900">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 30% 30%, #2f8fe0 0%, #163d80 40%, #0a1a3f 100%)',
          }}
        />
        {/* Cloud texture blobs */}
        {[
          { top: '15%', left: '10%', w: 90, h: 50 },
          { top: '35%', left: '45%', w: 120, h: 60 },
          { top: '60%', left: '15%', w: 100, h: 55 },
          { top: '55%', left: '55%', w: 80, h: 45 },
        ].map((c, i) => (
          <motion.div
            key={i}
            animate={{ x: [0, 10, 0] }}
            transition={{ duration: 6 + i, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute rounded-full bg-white/80 blur-xl"
            style={{ top: c.top, left: c.left, width: c.w, height: c.h, opacity: 0.85 }}
          />
        ))}

        <div className="relative z-10 flex flex-col items-center gap-2 text-mist-100/90">
          <CloudUpload className="h-8 w-8" strokeWidth={1.5} />
          <span className="text-xs font-medium">clouded_tile_0472.tif</span>
        </div>
      </div>

      <div className="flex items-center gap-2 text-xs text-mist-500">
        <ImageIcon className="h-3.5 w-3.5" strokeWidth={2} />
        <span>10m resolution · Sentinel-2 L2A · RGB composite</span>
      </div>
    </Card>
  )
}
