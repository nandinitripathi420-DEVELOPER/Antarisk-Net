import { motion } from 'framer-motion'
import { Download, Sparkles } from 'lucide-react'
import Card from '../ui/Card.jsx'

export default function OutputCard() {
  return (
    <Card className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-sm font-semibold text-mist-100">Reconstructed Frame</h3>
        <span className="flex items-center gap-1 rounded-full bg-cyan-glow/10 px-2.5 py-1 text-[10px] font-medium uppercase tracking-wider text-cyan-glow">
          <Sparkles className="h-3 w-3" strokeWidth={2.5} />
          AI Restored
        </span>
      </div>

      <div className="relative aspect-square overflow-hidden rounded-2xl border border-white/10">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 30% 25%, #37c98f 0%, #1d7f5c 30%, #0f4b3a 55%, #0a1a3f 100%)',
          }}
        />
        {/* Sharp terrain-like detail lines */}
        <svg className="absolute inset-0 h-full w-full opacity-40" viewBox="0 0 200 200">
          <path d="M0 60 Q 50 40 90 70 T 200 55" stroke="#eefaf3" strokeWidth="1" fill="none" />
          <path d="M0 120 Q 60 100 110 130 T 200 110" stroke="#eefaf3" strokeWidth="1" fill="none" />
          <path d="M0 160 Q 70 150 120 170 T 200 150" stroke="#eefaf3" strokeWidth="1" fill="none" />
        </svg>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="absolute bottom-3 left-3 rounded-lg bg-space-950/70 px-2.5 py-1 text-[10px] font-medium text-mist-100 backdrop-blur"
        >
          clouded_tile_0472_restored.tif
        </motion.div>
      </div>

      <button className="flex items-center justify-center gap-2 rounded-xl border border-white/10 py-2.5 text-xs font-medium text-mist-300 transition-colors hover:border-cyan-glow/40 hover:text-mist-100">
        <Download className="h-3.5 w-3.5" strokeWidth={2} />
        Export GeoTIFF
      </button>
    </Card>
  )
}
