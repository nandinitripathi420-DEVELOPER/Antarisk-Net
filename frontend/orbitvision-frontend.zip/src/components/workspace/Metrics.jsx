import { motion } from 'framer-motion'

const METRICS = [
  { label: 'SSIM Score', value: 96, display: '0.96' },
  { label: 'PSNR', value: 88, display: '31.2 dB' },
  { label: 'Cloud Coverage Removed', value: 99, display: '99.1%' },
  { label: 'Edge Fidelity', value: 92, display: '0.92' },
]

export default function Metrics() {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
      {METRICS.map((metric, i) => (
        <div key={metric.label} className="flex flex-col gap-2">
          <div className="flex items-baseline justify-between">
            <span className="text-xs text-mist-500">{metric.label}</span>
            <span className="font-display text-sm font-semibold text-mist-100">
              {metric.display}
            </span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/8">
            <motion.div
              initial={{ width: '0%' }}
              whileInView={{ width: `${metric.value}%` }}
              viewport={{ once: true }}
              transition={{ duration: 1.2, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="h-full rounded-full bg-gradient-to-r from-cyan-glow to-violet-glow"
            />
          </div>
        </div>
      ))}
    </div>
  )
}
