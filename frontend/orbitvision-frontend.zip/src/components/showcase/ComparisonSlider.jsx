import { useCallback, useRef, useState } from 'react'
import { MoveHorizontal } from 'lucide-react'

export default function ComparisonSlider() {
  const containerRef = useRef(null)
  const [position, setPosition] = useState(50)
  const dragging = useRef(false)

  const updatePosition = useCallback((clientX) => {
    const el = containerRef.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const pct = ((clientX - rect.left) / rect.width) * 100
    setPosition(Math.min(100, Math.max(0, pct)))
  }, [])

  const onPointerDown = (e) => {
    dragging.current = true
    updatePosition(e.clientX)
  }
  const onPointerMove = (e) => {
    if (!dragging.current) return
    updatePosition(e.clientX)
  }
  const stopDragging = () => {
    dragging.current = false
  }

  return (
    <div
      ref={containerRef}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={stopDragging}
      onPointerLeave={stopDragging}
      className="relative aspect-video w-full cursor-ew-resize select-none overflow-hidden rounded-3xl border border-white/10"
    >
      {/* Reconstructed (base layer) */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 35% 30%, #3fbf8f 0%, #1c7d5a 32%, #0f4b3a 58%, #0a1a3f 100%)',
        }}
      >
        <svg className="absolute inset-0 h-full w-full opacity-40" viewBox="0 0 400 225">
          <path d="M0 90 Q 100 60 180 100 T 400 80" stroke="#eefaf3" strokeWidth="1.5" fill="none" />
          <path d="M0 150 Q 120 120 220 160 T 400 140" stroke="#eefaf3" strokeWidth="1.5" fill="none" />
        </svg>
        <span className="absolute right-4 top-4 rounded-full bg-space-950/60 px-3 py-1 text-[11px] font-medium text-mist-100 backdrop-blur">
          AI Reconstructed
        </span>
      </div>

      {/* Cloudy (clipped top layer) */}
      <div
        className="absolute inset-0 overflow-hidden"
        style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }}
      >
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 35% 30%, #2f8fe0 0%, #163d80 40%, #0a1a3f 100%)',
          }}
        >
          {[
            { top: '18%', left: '8%', w: 120, h: 60 },
            { top: '40%', left: '40%', w: 150, h: 70 },
            { top: '62%', left: '10%', w: 130, h: 60 },
          ].map((c, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-white/85 blur-xl"
              style={{ top: c.top, left: c.left, width: c.w, height: c.h }}
            />
          ))}
        </div>
        <span className="absolute left-4 top-4 rounded-full bg-space-950/60 px-3 py-1 text-[11px] font-medium text-mist-100 backdrop-blur">
          Cloud-covered
        </span>
      </div>

      {/* Divider handle */}
      <div
        className="absolute top-0 h-full w-[2px] bg-mist-100/80"
        style={{ left: `${position}%` }}
      >
        <div className="absolute top-1/2 left-1/2 flex h-9 w-9 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-mist-100 text-space-950 shadow-[0_0_20px_rgba(0,0,0,0.4)]">
          <MoveHorizontal className="h-4 w-4" strokeWidth={2.25} />
        </div>
      </div>
    </div>
  )
}
